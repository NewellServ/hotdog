<?php session_start() ; ?><!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Karen loves hot dogs.</title>
    <link rel="stylesheet" href="/css/style.css">
    <meta name="description" content="My wife, Karen, loves hot dogs tremendously.  On this page you can purchase a hot dog for her and I will take a picture of her eating it and post it to the main page hot dog eating gallery.">
    <meta name="keywords" content="Karen, Newell, Karen Newell, Hot dog, I love hotdogs, hotdog, buy karen a hot dog, buy karen a hotdog">

  <?php require_once('header.php'); ?>
<body>
    <div class="wrapper">

      <h1>The store is currently closed.</h1>
      <br />
      <aside class="">
        "Karen is stuffed full."
      </aside>
      <br />

      <section>
          <article class="">
              <h3>See ya soon!</h3>
              <p>Karen got a little too full of all of your hotdogs and needed to take a break.  Make sure you are registered for the site and I'll let you know when she's ready to start taking hotdogs again.</p>
              <br /><br />
              <a href="register.php">register</a> - <a href="login.php">login</a>
              <br /><br />
          </article>
      </section>
    </div>
    <br /><br />
  </body>
<?php require_once('footer.php'); ?>
