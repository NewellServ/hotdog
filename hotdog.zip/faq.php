<?php session_start() ; ?><!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Karen loves hot dogs.</title>
    <link rel="stylesheet" href="/css/style.css">
    <meta name="description" content="My wife, Karen, loves hot dogs tremendously.  On this page you can purchase a hot dog for her and I will take a picture of her eating it and post it to the main page hot dog eating gallery.">
    <meta name="keywords" content="Karen, Newell, Karen Newell, Hot dog, I love hotdogs, hotdog, buy karen a hot dog, buy karen a hotdog">

  <?php require_once('header.php'); ?>
<body>
    <div class="wrapper">

      <h1>FAQ</h1>
      <br />



        <h3>What is this?</h3>
        <p>A fully interactive hot dog experience, currently with high latency.</p>

        <h3>I bought a hotdog, when is she going to eat it?</h3>
        <p>Get in line, Buddy!  This isn't an "immediately stuff a hotdog down Karen's throat" service. (Looking into that.)  Your time will come.</p>

      <h3>What exactly am I buying here?</h3>
      <p>I've bought a pack of hot dogs.  I'll sell you one at the current price of a hotdog on the main page.  Karen eats your hotdog.  I post picture of Karen eating your hotdog in the gallery.</p>


      <h3>Is one enough?</h3>
      <p>No.  By my calculations she'll need a couple of thousand hotdogs.</p>

      <h3>I've already lost hundreds of dollars on meme stock, sell me on a hotdog.</h3>
      <p>Well, my wife loves hotdogs and she'd love to eat yours!</p>

      <h3>So... Is this like a sex thing?</h3>
      <p>How dare you insult our pride!  She is simply eating other peoples hotdogs for a price.</p>

      <h3>So, if you have hotdogs why would I buy them?</h3>
      <p>It's <em>your</em> hotdog.</p>

       <h3>What exactly is a hotdog?</h3>
       <p>According to google: "a frankfurter, especially one served hot in a long, soft roll and topped with various condiments."  Or it can apparently be "a person who shows off, especially a skier or surfer who performs stunts or tricks."  Though getting her to eat your surfer may cost more.</p>

        <h3>Whats the current rate of hotdog consumption?</h3>
        <p>Right now, we are at about 1-3 hotdogs a day.  We are looking into ways to improve this.</p>

        <h3>Can I get a stool sample?</h3>
        <p>Not at this time.</p>

        <h3>Can I make a request or get a personal touch?</h3>
        <p>You may request one, but I cannot ensure Karen will comply with your request.  Feel free, though.</p>

        <h3>Whats the max number of simultaneous dogs in mouth?</h3>
        <p>The limit is theoretically infinite, though she hasn't yet been convinced to simultaneously eat your hotdogs.</p>

        <h3>Did a tree fall on your house?</h3>
        <p>Yes.  Please buy more hotdogs.</p>

        <h3>Do you have any more hotdog eating models?</h3>
        <p>Not at this time.</p>

        <h3>Can I send Karen a personal message?</h3>
        <p>Not at this time.</p>


        <br /><br />
    </div>
  </body>
<?php require_once('footer.php'); ?>
