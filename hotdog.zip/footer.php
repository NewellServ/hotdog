<footer>
  <div class="navWrapper">

      <div class="footerLinks">
          <ul>
              <a href="changelog.php"><li>changelog</li></a>
              <a href="faq.php"><li>faq</li></a>
              <a href="founders.php"><li>&#127789;</li></a>
          </ul>
      </div>

      <a style="color: white ;" href="https://www.newellserv.com">
          &copy; <?php echo date("Y") ; ?> Newell<font style="color: #3B5997">Serv</font>
      </a>
  </div>

</footer>
</html>
