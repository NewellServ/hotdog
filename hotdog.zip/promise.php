<?php session_start() ; ?><!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Karen loves hot dogs.</title>
    <link rel="stylesheet" href="/css/style.css">
    <meta name="description" content="My wife, Karen, loves hot dogs tremendously.  On this page you can purchase a hot dog for her and I will take a picture of her eating it and post it to the main page hot dog eating gallery.">
    <meta name="keywords" content="Karen, Newell, Karen Newell, Hot dog, I love hotdogs, hotdog, buy karen a hot dog, buy karen a hotdog">

  <?php require_once('header.php'); ?>
<body>
    <div class="wrapper">

      <h1>The Hotdog Promise</h1>
      <br />

      <br />

      <section>
          <article class="">
              <h3>We agree on the following...</h3>
              <p>Look, I don't want to screw you and I know you don't want to screw me.  We mutually agree to try and not fuck each other over.  You buy the hotdog, I'll feed it to her and give you a picture of it.  Thats it.</p>
              <p>Hotdog-purchase to hotdog-consumption may be an extended wait, your spot is saved in line.</p>
              <p>Things that are tasteful, funny, or complimentory will be passed on!  Things that are not will be moderated.</p>
              <p>Enjoy!</p>

                <a href="register.php">register</a> - <a href="login.php">login</a>

          </article>
      </section>
    </div>
    <br /><br />
  </body>
<?php require_once('footer.php'); ?>
